<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>NAS Management Interface</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>NAS Management Interface</h1>
        <a href="users.php">Manage Users</a>
    </div>
</body>
</html>